﻿namespace hw_2_wind_form
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            listBox1 = new ListBox();
            button17 = new Button();
            groupBox1 = new GroupBox();
            numericUpDown1 = new NumericUpDown();
            progressBar1 = new ProgressBar();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 12);
            button1.Name = "button1";
            button1.Size = new Size(77, 68);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(95, 12);
            button2.Name = "button2";
            button2.Size = new Size(77, 68);
            button2.TabIndex = 0;
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(178, 12);
            button3.Name = "button3";
            button3.Size = new Size(77, 68);
            button3.TabIndex = 0;
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(261, 12);
            button4.Name = "button4";
            button4.Size = new Size(77, 68);
            button4.TabIndex = 0;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(12, 86);
            button5.Name = "button5";
            button5.Size = new Size(77, 68);
            button5.TabIndex = 0;
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(95, 86);
            button6.Name = "button6";
            button6.Size = new Size(77, 68);
            button6.TabIndex = 0;
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(178, 86);
            button7.Name = "button7";
            button7.Size = new Size(77, 68);
            button7.TabIndex = 0;
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(261, 86);
            button8.Name = "button8";
            button8.Size = new Size(77, 68);
            button8.TabIndex = 0;
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(12, 160);
            button9.Name = "button9";
            button9.Size = new Size(77, 68);
            button9.TabIndex = 0;
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(95, 160);
            button10.Name = "button10";
            button10.Size = new Size(77, 68);
            button10.TabIndex = 0;
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(178, 160);
            button11.Name = "button11";
            button11.Size = new Size(77, 68);
            button11.TabIndex = 0;
            button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(261, 160);
            button12.Name = "button12";
            button12.Size = new Size(77, 68);
            button12.TabIndex = 0;
            button12.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(12, 234);
            button13.Name = "button13";
            button13.Size = new Size(77, 68);
            button13.TabIndex = 0;
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(95, 234);
            button14.Name = "button14";
            button14.Size = new Size(77, 68);
            button14.TabIndex = 0;
            button14.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.Location = new Point(178, 234);
            button15.Name = "button15";
            button15.Size = new Size(77, 68);
            button15.TabIndex = 0;
            button15.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.Location = new Point(261, 234);
            button16.Name = "button16";
            button16.Size = new Size(77, 68);
            button16.TabIndex = 0;
            button16.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(344, 12);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(81, 184);
            listBox1.TabIndex = 1;
            // 
            // button17
            // 
            button17.Location = new Point(344, 202);
            button17.Name = "button17";
            button17.Size = new Size(81, 39);
            button17.TabIndex = 0;
            button17.Text = "Start";
            button17.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(numericUpDown1);
            groupBox1.Location = new Point(344, 247);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(81, 55);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "GameTime";
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(15, 22);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(47, 23);
            numericUpDown1.TabIndex = 0;
            numericUpDown1.Value = new decimal(new int[] { 25, 0, 0, 0 });
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(12, 308);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(413, 28);
            progressBar1.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(441, 346);
            Controls.Add(progressBar1);
            Controls.Add(groupBox1);
            Controls.Add(listBox1);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            MaximizeBox = false;
            Name = "Form1";
            Text = "My Game";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private ListBox listBox1;
        private Button button17;
        private GroupBox groupBox1;
        private NumericUpDown numericUpDown1;
        private ProgressBar progressBar1;
    }
}
