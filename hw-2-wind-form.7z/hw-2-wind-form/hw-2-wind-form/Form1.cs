using System.Windows.Forms;

namespace hw_2_wind_form
{
    public partial class Form1 : Form
    {
        private int[] numbers;
        private int currentNumber;
        private int timeLimit;
        private System.Windows.Forms.Timer gameTimer;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            gameTimer = new();
            gameTimer.Interval = 1000;
            gameTimer.Tick += GameTimer_Tick;

            button17.Click += StartGame;

            foreach (var control in Controls)
            {
                if (control is Button button && button.Name.StartsWith("button") && button.Name != "button17")
                {
                    button.Click += Button_Click;
                }
            }
        }

        private void StartGame(object sender, EventArgs e)
        {
            Random random = new Random();
            numbers = Enumerable.Range(1, 100)
                .OrderBy(x => random.Next())
                .Take(16)
                .ToArray();

            var buttons = Controls.OfType<Button>().Where(b => b.Name.StartsWith("button") && b.Name != "button17").ToList();

            for (int i = 0; i < buttons.Count; i++)
            {
                buttons[i].Text = numbers[i].ToString();
                buttons[i].Enabled = true;
                buttons[i].BackColor = SystemColors.Control;
            }

            Array.Sort(numbers);

            currentNumber = 0;
            listBox1.Items.Clear();

            timeLimit = (int)numericUpDown1.Value;
            progressBar1.Maximum = timeLimit;
            progressBar1.Value = 0;

            gameTimer.Start();
        }

        private void Button_Click(object sender, EventArgs e)
        {
            if (sender is Button button && int.TryParse(button.Text, out int number))
            {
                if (number == numbers[currentNumber])
                {
                    listBox1.Items.Add(number);
                    button.Enabled = false;
                    button.BackColor = Color.Gray;
                    currentNumber++;

                    if (listBox1.Items.Count == 16)
                    {
                        progressBar1.Value = 0;
                        gameTimer.Stop();
                        MessageBox.Show("Congratulations! You've won!", "Game over.", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < progressBar1.Maximum)
            {
                progressBar1.Value++;
            }
            else
            {
                progressBar1.Value = 0;
                gameTimer.Stop();
                MessageBox.Show("Time's up! You've lost!", "Game over", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
